//Lenon, Danielle Laurence B. | CS-301 | 7.16.2025

import 'Avenger.dart'; //Thor.dart uses classes, methods, and variables defined in Avenger.dart

class Thor extends Avenger {
  Thor() : super("Thor", "God of Thunder and Mjolnir"); //Initializing name and power in constructor Thor

  @override
  void usePower() {
    print("$name summons lightning with $power!");
  } //In the case of Thor.dart, it overrides the abstract method in the abstract class to customize behavior
} //Thor.dart is the child class