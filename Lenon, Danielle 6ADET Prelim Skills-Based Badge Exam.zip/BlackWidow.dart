//Lenon, Danielle Laurence B. | CS-301 | 7.16.2025

import 'Avenger.dart'; //BlackWidow.dart uses classes, methods, and variables defined in Avenger.dart

class BlackWidow extends Avenger {
  BlackWidow() : super("Black Widow", "Martial Arts"); //Initializing name and power in constructor BlackWidow

  @override
  void usePower() {
    print("$name attacks swiftly using $power!");
  } //In the case of BlackWidow.dart, it overrides the abstract method in the abstract class to customize behavior
} //BlackWidow.dart is the child class