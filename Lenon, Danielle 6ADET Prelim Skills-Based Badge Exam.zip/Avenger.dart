//Lenon, Danielle Laurence B. | CS-301 | 7.16.2025

abstract class Avenger {
  late String avengername, avengerpower; //Private fields declared as late to initialize later

  Avenger(String name, String power) {
    this.avengername = name;
    this.avengerpower = power;
  } //Constructor for name and power

  String get name {
    return this.avengername;
  } //get method for name

  set name(String newName) {
    avengername = newName;
  } //set method for name

  String get power {
    return this.avengerpower;
  } //get method for power

  set power(String newPower) {
    this.avengerpower = newPower;
  } //get method for power

  void usePower(); //abstract method
} //Avenger.dart is the parent class