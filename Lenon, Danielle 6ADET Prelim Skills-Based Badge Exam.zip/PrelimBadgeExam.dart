//Lenon, Danielle Laurence B. | CS-301 | 7.16.2025

import 'Avenger.dart'; //PrelimBadgeExam.dart uses classes, methods, and variables defined in Avenger.dart
import 'BlackWidow.dart'; //PrelimBadgeExam.dart uses classes, methods, and variables defined in BlackWidow.dart
import 'CaptainAmerica.dart'; //PrelimBadgeExam.dart uses classes, methods, and variables defined in CaptainAmerica.dart
import 'Ironman.dart'; //PrelimBadgeExam.dart uses classes, methods, and variables defined in Ironman.dart
import 'Thor.dart'; //PrelimBadgeExam.dart uses classes, methods, and variables defined in Thor.dart

void main() {
  Avenger blckwdw = BlackWidow(); //Polymorphism to create a new object of BlackWidow.dart and storing it in a variable of type Avenger, a parent class
  Avenger cptnamrca = CaptainAmerica(); //Polymorphism to create a new object of CaptainAmerica.dart and storing it in a variable of type Avenger, a parent class
  Avenger irnmn = Ironman(); //Polymorphism to create a new object of Ironman.dart and storing it in a variable of type Avenger, a parent class
  Avenger thr = Thor(); //Polymorphism to create a new object of Thor.dart and storing it in a variable of type Avenger, a parent class

  blckwdw.avengername = "Black Widow"; //Use set method for the name
  cptnamrca.avengername = "Captain America"; //Use set method for the name
  irnmn.avengername = "Ironman"; //Use set method for the name
  thr.avengername = "Thor"; //Use set method for the name

  List<Avenger> avengerteam = [blckwdw, cptnamrca, irnmn, thr]; //List of all members in the Avenger Team

  print("AVENGERS ASSEMBLY!\n");

  for (var avenger in avengerteam) {
    avenger.usePower();
  } //Loop a number of times based on how many members are there in the Avenger Team; in this case, it's 4.

  print("\nHere is a bonus!\nAVENGERS UPDATING SUPERPOWERS! ASSEMBLY!\n");
  irnmn.power = "Nano-tech armor and AI targeting";
  blckwdw.power = "Invisibility and electric batons";
  irnmn.usePower(); //Updates the private field avengerpower in the Avenger object for a dynamic change
  blckwdw.usePower(); //Updates the private field avengerpower in the Avenger object for a dynamic change
} //PrelimBadgeExam.dart is the main file, where the main method resides