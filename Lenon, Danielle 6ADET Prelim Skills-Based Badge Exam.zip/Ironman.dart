//Lenon, Danielle Laurence B. | CS-301 | 7.16.2025

import 'Avenger.dart'; //Ironman.dart uses classes, methods, and variables defined in Avenger.dart

class Ironman extends Avenger {
  Ironman() : super("Ironman", "Repulsor Blasts and Suit Technology"); //Initializing name and power in constructor Ironman

  @override
  void usePower() {
    print("$name uses $power!");
  } //In the case of Ironman.dart, it overrides the abstract method in the abstract class to customize behavior
} //Ironman.dart is the child class