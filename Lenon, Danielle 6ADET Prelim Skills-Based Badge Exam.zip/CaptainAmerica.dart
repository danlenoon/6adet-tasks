//Lenon, Danielle Laurence B. | CS-301 | 7.16.2025

import 'Avenger.dart'; //CaptainAmerica.dart uses classes, methods, and variables defined in Avenger.dart

class CaptainAmerica extends Avenger {
  CaptainAmerica() : super("Captain America", "Shield Throw"); //Initializing name and power in constructor CaptainAmerica

  @override
  void usePower() {
    print("$name throws his shield with $power!");
  } //In the case of CaptainAmerica.dart, it overrides the abstract method in the abstract class to customize behavior
} //CaptainAmerica.dart is the child class