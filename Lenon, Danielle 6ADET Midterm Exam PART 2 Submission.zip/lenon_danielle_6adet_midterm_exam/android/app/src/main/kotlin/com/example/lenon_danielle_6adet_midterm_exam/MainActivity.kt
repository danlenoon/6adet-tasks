package com.example.lenon_danielle_6adet_midterm_exam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
