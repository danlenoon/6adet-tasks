//Lenon, Danielle Laurence B. | CS-301 | 9.6.2025

import 'package:flutter/material.dart';

class FirstScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('First Screen'),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Text(
          'First Screen',
          style: TextStyle(fontSize: 24, color: Colors.white),
        ),
      ),
      backgroundColor: Colors.red,
    );
  }
}