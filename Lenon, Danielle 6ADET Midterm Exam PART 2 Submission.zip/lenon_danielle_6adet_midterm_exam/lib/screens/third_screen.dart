//Lenon, Danielle Laurence B. | CS-301 | 9.6.2025

import 'package:flutter/material.dart';

class ThirdScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Third Screen'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Text(
          'Third Screen',
          style: TextStyle(fontSize: 24, color: Colors.white),
        ),
      ),
      backgroundColor: Colors.blue,
    );
  }
}