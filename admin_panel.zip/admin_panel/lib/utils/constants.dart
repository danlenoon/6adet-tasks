import 'package:flutter/material.dart';
import '../models/product.dart';

// Add the PopupType enum at the top
enum PopupType { success, error }

// Sample product data
List<Product> products = [
  Product(
    id: 1,
    name: "Banana Headphones",
    category: "Audio",
    price: 699.99,
    stock: 123,
  ),
  Product(
    id: 2,
    name: "Laptop Bag",
    category: "Accessories",
    price: 249.99,
    stock: 22,
  ),
  Product(
    id: 3,
    name: "Banana Microphone",
    category: "Audio",
    price: 150.99,
    stock: 76,
  ),
  Product(
    id: 4,
    name: "TYPE-C Cord",
    category: "Accessories",
    price: 100.00,
    stock: 320,
  ),
  Product(
    id: 5,
    name: "Banana Camera",
    category: "Electronics",
    price: 1500.00,
    stock: 45,
  ),
];

// App colors - Updated to match the original design
const Color primaryColor = Color(0xFF000000);
const Color backgroundColor = Color(0xFFFFFFFF);
const Color cardColor = Color(0xFFFFFFFF);
const Color textColor = Color(0xFF000000);
const Color borderColor = Color(0xFFDDDDDD);
const Color dividerColor = Color(0xFFEEEEEE);

// Text styles - Updated to match the original design
const TextStyle headerStyle = TextStyle(
  fontSize: 22,
  fontWeight: FontWeight.bold,
  color: textColor,
);

const TextStyle subtitleStyle = TextStyle(
  fontSize: 18,
  fontWeight: FontWeight.w600,
  color: textColor,
);

const TextStyle bodyStyle = TextStyle(
  fontSize: 16,
  color: textColor,
);

const TextStyle tableHeaderStyle = TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.bold,
  color: textColor,
);

const TextStyle tableCellStyle = TextStyle(
  fontSize: 14,
  color: textColor,
);

const TextStyle summaryLabelStyle = TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.normal,
  color: textColor,
);

const TextStyle summaryValueStyle = TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.bold,
  color: textColor,
);