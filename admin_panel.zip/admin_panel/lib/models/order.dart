class Order {
  final int id;
  final int userId;
  final String status;

  Order({
    required this.id,
    required this.userId,
    required this.status,
  });
}

// Sample data
List<Order> orders = [
  Order(id: 1, userId: 2, status: "Shipped"),
  Order(id: 2, userId: 3, status: "Pending"),
  Order(id: 3, userId: 3, status: "Delivered"),
  Order(id: 4, userId: 1, status: "Failed"),
  Order(id: 5, userId: 4, status: "Shipped"),
];