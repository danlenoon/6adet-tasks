class Product {
  final int id;
  final String name;
  final String category;
  final double price;
  final int stock;
  final String? imageUrl;
  final List<String> variations;

  Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.stock,
    this.imageUrl,
    this.variations = const [],
  });

  Product copyWith({
    int? id,
    String? name,
    String? category,
    double? price,
    int? stock,
    String? imageUrl,
    List<String>? variations,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      price: price ?? this.price,
      stock: stock ?? this.stock,
      imageUrl: imageUrl ?? this.imageUrl,
      variations: variations ?? this.variations,
    );
  }
}