import 'package:flutter/material.dart';
import '../utils/constants.dart';

class AnalyticsPage extends StatefulWidget {
  const AnalyticsPage({super.key});

  @override
  State<AnalyticsPage> createState() => _AnalyticsPageState();
}

class _AnalyticsPageState extends State<AnalyticsPage> {
  String selectedMonth = 'SEPTEMBER';
  String selectedYear = '2025';
  String selectedCategory = 'Earwear';

  // Sample sales data for the line graph
  final List<double> salesData = [12, 18, 15, 22, 30, 25, 35, 40, 38, 45];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Text(
              'Display Data for ANALYTICS',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Sales for:',
              style: headerStyle,
            ),
            const SizedBox(height: 16),
            // Dropdowns in a single row with rounded borders
            Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: borderColor),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: DropdownButton<String>(
                      value: selectedMonth,
                      isExpanded: true,
                      underline: const SizedBox(), // Remove default underline
                      style: const TextStyle(color: Colors.black, fontSize: 16),
                      items: const [
                        DropdownMenuItem(value: 'SEPTEMBER', child: Text('SEPTEMBER')),
                        DropdownMenuItem(value: 'OCTOBER', child: Text('OCTOBER')),
                        DropdownMenuItem(value: 'NOVEMBER', child: Text('NOVEMBER')),
                        DropdownMenuItem(value: 'DECEMBER', child: Text('DECEMBER')),
                      ],
                      onChanged: (value) {
                        setState(() {
                          selectedMonth = value!;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: borderColor),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: DropdownButton<String>(
                      value: selectedYear,
                      isExpanded: true,
                      underline: const SizedBox(), // Remove default underline
                      style: const TextStyle(color: Colors.black, fontSize: 16),
                      items: const [
                        DropdownMenuItem(value: '2025', child: Text('2025')),
                        DropdownMenuItem(value: '2024', child: Text('2024')),
                        DropdownMenuItem(value: '2023', child: Text('2023')),
                      ],
                      onChanged: (value) {
                        setState(() {
                          selectedYear = value!;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: borderColor),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: DropdownButton<String>(
                      value: selectedCategory,
                      isExpanded: true,
                      underline: const SizedBox(), // Remove default underline
                      style: const TextStyle(color: Colors.black, fontSize: 16),
                      items: const [
                        DropdownMenuItem(value: 'Earwear', child: Text('Earwear')),
                        DropdownMenuItem(value: 'Accessories', child: Text('Accessories')),
                        DropdownMenuItem(value: 'Electronics', child: Text('Electronics')),
                      ],
                      onChanged: (value) {
                        setState(() {
                          selectedCategory = value!;
                        });
                      },
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text(
              'Quantity Sold',
              style: subtitleStyle,
            ),
            const SizedBox(height: 16),
            // Line graph representation
            Container(
              height: 200,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(color: borderColor),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomPaint(
                size: const Size(double.infinity, 200),
                painter: LineGraphPainter(salesData: salesData),
              ),
            ),
            const SizedBox(height: 16),
            const Center(
              child: Text(
                'Days',
                style: bodyStyle,
              ),
            ),
            const SizedBox(height: 32),
            const Divider(color: dividerColor),
            const SizedBox(height: 16),
            const Text(
              'Summary of Sales',
              style: subtitleStyle,
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(color: borderColor),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Summary for:', style: summaryLabelStyle),
                      Text('SEPTEMBER 2025', style: summaryValueStyle),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Divider(color: dividerColor, height: 1),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Number of Products:', style: summaryLabelStyle),
                      Text('12', style: summaryValueStyle),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Number of Sales:', style: summaryLabelStyle),
                      Text('3', style: summaryValueStyle),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Number of Concurrent Users:', style: summaryLabelStyle),
                      Text('12', style: summaryValueStyle),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total Revenue:', style: summaryLabelStyle),
                      Text('P1234.0', style: summaryValueStyle),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Divider(color: dividerColor, thickness: 1.0),
            const SizedBox(height: 20),
            // Menu buttons - now full width with centered text
            Column(
              children: [
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0),
                      ),
                      side: const BorderSide(color: Colors.grey, width: 0.5),
                    ),
                    child: const Text(
                      'PRODUCTS',
                      style: TextStyle(fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0),
                      ),
                      side: const BorderSide(color: Colors.grey, width: 0.5),
                    ),
                    child: const Text(
                      'ORDERS',
                      style: TextStyle(fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0),
                      ),
                    ),
                    child: const Text(
                      'ANALYTICS',
                      style: TextStyle(fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            // RETURN TO MAIN MENU button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                child: const Text(
                  'RETURN TO MAIN MENU',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Custom painter for the line graph
class LineGraphPainter extends CustomPainter {
  final List<double> salesData;
  
  LineGraphPainter({required this.salesData});
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = primaryColor
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
      
    final fillPaint = Paint()
      ..color = primaryColor.withOpacity(0.2)
      ..style = PaintingStyle.fill;
    
    final dotPaint = Paint()
      ..color = primaryColor
      ..style = PaintingStyle.fill;
    
    final textStyle = TextStyle(
      color: Colors.black,
      fontSize: 10,
    );
    
    final textPainter = TextPainter(
      textDirection: TextDirection.ltr,
    );
    
    if (salesData.isEmpty) return;
    
    // Calculate the maximum value for scaling
    final maxValue = salesData.reduce((a, b) => a > b ? a : b) * 1.1;
    
    // Calculate points for the line
    final points = <Offset>[];
    final spacing = size.width / (salesData.length - 1);
    
    for (int i = 0; i < salesData.length; i++) {
      final x = i * spacing;
      final y = size.height - (salesData[i] / maxValue * size.height);
      points.add(Offset(x, y));
    }
    
    // Draw filled area under the line
    final path = Path();
    path.moveTo(points.first.dx, size.height);
    for (final point in points) {
      path.lineTo(point.dx, point.dy);
    }
    path.lineTo(points.last.dx, size.height);
    path.close();
    
    canvas.drawPath(path, fillPaint);
    
    // Draw the line
    for (int i = 0; i < points.length - 1; i++) {
      canvas.drawLine(points[i], points[i + 1], paint);
    }
    
    // Draw points and labels
    for (int i = 0; i < points.length; i++) {
      // Draw data points
      canvas.drawCircle(points[i], 4, dotPaint);
      
      // Draw day labels
      textPainter.text = TextSpan(
        text: '${i + 1}',
        style: textStyle,
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(points[i].dx - textPainter.width / 2, size.height - textPainter.height + 4),
      );
      
      // Draw value labels
      textPainter.text = TextSpan(
        text: salesData[i].toStringAsFixed(0),
        style: textStyle,
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(points[i].dx - textPainter.width / 2, points[i].dy - textPainter.height - 4),
      );
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}