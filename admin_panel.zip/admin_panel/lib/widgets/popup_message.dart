import 'package:flutter/material.dart';
import '../utils/constants.dart';

class PopupMessageWidget extends StatelessWidget {
  final String message;
  final PopupType type;

  const PopupMessageWidget({
    Key? key,  // Changed from super.key to Key? key
    required this.message,
    required this.type,
  }) : super(key: key);  // Added super call

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          Icon(
            type == PopupType.success ? Icons.check_circle : Icons.error,
            color: type == PopupType.success ? Colors.green : Colors.red,
          ),
          const SizedBox(width: 8),
          Text(
            type == PopupType.success ? 'Success' : 'Error',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: type == PopupType.success ? Colors.green : Colors.red,
            ),
          ),
        ],
      ),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Confirm'),
        ),
      ],
    );
  }
}