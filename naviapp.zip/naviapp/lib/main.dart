import 'package:flutter/material.dart';
import 'package:naviapp/screens/logo_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    var logoPage = LogoPage();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Form Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: logoPage,
    );
  }
}