class Animal{
  void sound(){
    print('sound of silence');
  }

  void food(){
    print('any food');
  }

}