import 'animal.dart';

class Frog extends Animal{
@override
  void sound(){
    print('ngork! ngork! rebeet!');
  }

  @override
  void food(){
    print('insects');
  }

}