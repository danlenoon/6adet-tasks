import 'animal.dart';
import 'dog.dart';
import 'cat.dart';
import 'chicken.dart';
import 'frog.dart';
void main() {
  Animal pet;
  
  pet = Dog();
  pet.sound();
  pet.food();
 
  pet = Cat();
  pet.sound();
  pet.food();

  pet = Chicken();
  pet.sound();
  pet.food();

  pet = Frog();
  pet.sound();
  pet.food();
  
}













 //var newphone = SamsungFlip();
  //newphone.bluetoothon();
  //newphone.bluetoothoff();


  //INHERITANCE 
  //import 'cherrymobile.dart';
  //var cherry = Cherrymobile();
  //cherry.displayScreen();
  //cherry.vibrate();
  //cherry.poweroff();