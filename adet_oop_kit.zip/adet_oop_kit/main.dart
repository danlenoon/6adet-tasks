import 'samsungmobile.dart';

void main() {
  var newphone = SamsungFlip();
  newphone.bluetoothon();
  newphone.bluetoothoff();
}













 //var newphone = SamsungFlip();
  //newphone.bluetoothon();
  //newphone.bluetoothoff();


  //INHERITANCE 
  //import 'cherrymobile.dart';
  //var cherry = Cherrymobile();
  //cherry.displayScreen();
  //cherry.vibrate();
  //cherry.poweroff();