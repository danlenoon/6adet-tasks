import 'animal.dart';

class Cat extends Animal{
  @override
  void sound(){
    print('meow! meow! meow! meow!');
  }

  @override
  void food(){
    print('fish');
  }

}