
class MobilePhone{
     void vibrate(){
        print('Phone is vibrating');
     }
     void poweroff(){
       print('Phone is powering off');
     }  
     void volumeup(){
       print('Volume Up ++');
     }

}


