import 'huawei.dart';

void main(){
  var myphone = HuaweiPhone();
  myphone.model ='Horror';
  myphone.battery=3500;
  myphone.displayMobileInfo();
}
