
import 'windowsphone.dart';

class SamsungFlip implements WindowsMobile{
 //@override
  void bluetoothon(){
     print('The bluetooth device is ready to pair');
   }

 @override
 void bluetoothoff()=> print('The bluetooth device is disconnected');
}


