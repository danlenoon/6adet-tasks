import 'dart:io';

void main(){
 int no=3; 
 int newCallTimes = callme(no);
 print('Please call me maybe? $newCallTimes times');
}
int callme(int receivedvalue){
   receivedvalue = receivedvalue + 2; 
   return receivedvalue;
 }