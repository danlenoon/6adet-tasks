abstract class WindowsMobile {
  void bluetoothon();
  void bluetoothoff();
}

