import 'animal.dart';

class Chicken extends Animal{
@override
  void sound(){
    print('coo! coo! coo!');
  }

  @override
  void food(){
    print('feeds');
  }

}