class HuaweiPhone {
  String _model ='Oppo';
  int _battery =0;
  String get model => _model;
  set model(String value) => _model = value;
  int get battery => _battery;
  set battery(int value){
   if (value == 0 || value < 0 ){
        print('battery is emotionally damaged!');       
    }
    else{
        print('battery is in good condition!');       
    }
  }
  void displayMobileInfo(){
    print("Phone: $_model, Battery: $_battery mah");
  }
  

} 
 