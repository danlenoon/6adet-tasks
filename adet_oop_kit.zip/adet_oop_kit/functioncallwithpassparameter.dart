import 'dart:io';

void main(){
 callme(3);
}
void callme(int receivedvalue){
   print('Please call me maybe? $receivedvalue times');
 }