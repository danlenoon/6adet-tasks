
import 'mobilephone.dart';

class Cherrymobile extends MobilePhone{
  String name ='Cherry Mobile';
  void displayScreen(){
    print('Welcome to $name');
  } 
}

 