import 'animal.dart';

class Dog extends Animal{
  @override
  void sound(){
    print('Aw! Aw!');
  }

  @override
  void food(){
    print('bone');
  }

}